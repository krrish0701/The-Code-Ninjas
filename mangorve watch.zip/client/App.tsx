import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Report from "./pages/Report";
import { Leaf, Camera, Home } from "lucide-react";

const queryClient = new QueryClient();

function Header() {
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/90 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
        <NavLink to="/" className="inline-flex items-center gap-2">
          <Leaf className="h-5 w-5 text-primary" />
          <span className="font-semibold tracking-tight">MangroveGuard</span>
        </NavLink>
        <a
          href="/#how-it-works"
          className="text-sm text-muted-foreground hover:text-foreground"
        >
          How it works
        </a>
      </div>
    </header>
  );
}

function MobileNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 mx-auto max-w-3xl border-t bg-background/95 px-6 py-2 backdrop-blur supports-[backdrop-filter]:bg-background/70 md:hidden">
      <div className="grid grid-cols-3 gap-3">
        <NavLink
          to="/"
          className={({ isActive }) =>
            `flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm ${isActive ? "bg-accent text-accent-foreground" : "text-muted-foreground"}`
          }
        >
          <Home className="h-4 w-4" />
          <span>Home</span>
        </NavLink>
        <NavLink
          to="/report"
          className={({ isActive }) =>
            `flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm ${isActive ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`
          }
        >
          <Camera className="h-4 w-4" />
          <span>Report</span>
        </NavLink>
        <a
          href="/#impact"
          className="flex items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm text-muted-foreground"
        >
          <Leaf className="h-4 w-4" />
          <span>Impact</span>
        </a>
      </div>
    </nav>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <div className="flex min-h-dvh flex-col">
          <Header />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/report" element={<Report />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <footer className="hidden border-t bg-background/80 md:block">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 text-sm text-muted-foreground">
              <p>© {new Date().getFullYear()} MangroveGuard</p>
              <p>Built for DA-IICT Hackathon 2025</p>
            </div>
          </footer>
          <MobileNav />
        </div>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
