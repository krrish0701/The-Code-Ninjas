import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Award, Camera, MapPin, Shield, Users } from "lucide-react";

export default function Index() {
  const [points, setPoints] = useState(0);
  const reports = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem("mg_reports") || "[]").slice(0, 5);
    } catch {
      return [];
    }
  }, []);

  useEffect(() => {
    setPoints(Number(localStorage.getItem("mg_points") || "0"));
  }, []);

  return (
    <div className="relative">
      <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(1000px_400px_at_50%_-20%,hsl(var(--primary)/0.12),transparent_60%),radial-gradient(800px_300px_at_70%_20%,hsl(var(--secondary)/0.15),transparent_60%)]" />

      <section className="mx-auto max-w-6xl px-4 pb-24 pt-10 md:grid md:grid-cols-2 md:items-center md:gap-8 md:pt-16">
        <div>
          <Badge variant="secondary" className="mb-3">Participatory conservation</Badge>
          <h1 className="text-balance text-4xl font-extrabold tracking-tight sm:text-5xl">
            Protect Mangroves with your phone
          </h1>
          <p className="mt-4 text-balance text-base text-muted-foreground sm:text-lg">
            MangroveGuard empowers coastal communities, fishers, and citizen scientists to report mangrove threats with geotagged photos. AI-assisted validation and satellite data ensure reliable, real-time alerts for authorities.
          </p>
          <div className="mt-6 flex gap-3">
            <Button asChild>
              <a href="/report" className="inline-flex items-center gap-2">
                <Camera className="h-4 w-4" /> Report incident
              </a>
            </Button>
            <Button variant="outline" asChild>
              <a href="#how-it-works">How it works</a>
            </Button>
          </div>
          <div className="mt-6 flex items-center gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-2"><Shield className="h-4 w-4 text-primary" /> AI validation</div>
            <div className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" /> Geotagged</div>
            <div className="flex items-center gap-2"><Award className="h-4 w-4 text-primary" /> Rewards</div>
          </div>
        </div>
        <div className="mt-10 md:mt-0">
          <div className="rounded-xl border bg-card/70 p-4 shadow-sm backdrop-blur">
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="rounded-lg bg-muted/50 p-4">
                <p className="text-3xl font-bold">{points}</p>
                <p className="text-xs text-muted-foreground">Your points</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-4">
                <p className="text-3xl font-bold">{reports.length}</p>
                <p className="text-xs text-muted-foreground">Recent reports</p>
              </div>
              <div className="rounded-lg bg-muted/50 p-4">
                <p className="text-3xl font-bold">24h</p>
                <p className="text-xs text-muted-foreground">Avg. response</p>
              </div>
            </div>
            <Separator className="my-4" />
            <h3 className="mb-2 text-sm font-semibold">Community leaderboard</h3>
            <div className="grid gap-2">
              <LeaderboardRow place={1} name="You" points={points} highlight />
              <LeaderboardRow place={2} name="BlueBay Fishers" points={820} />
              <LeaderboardRow place={3} name="Delta Rangers" points={790} />
            </div>
          </div>
        </div>
      </section>

      <section id="how-it-works" className="mx-auto max-w-6xl px-4 pb-24">
        <div className="grid gap-6 md:grid-cols-3">
          <FeatureCard icon={<Camera className="h-5 w-5" />} title="Report with evidence" desc="Capture a geotagged photo and description via mobile or SMS." />
          <FeatureCard icon={<Shield className="h-5 w-5" />} title="AI-assisted validation" desc="Models flag duplicates and anomalies, boosting data reliability." />
          <FeatureCard icon={<MapPin className="h-5 w-5" />} title="Satellite context" desc="Overlay reports with satellite layers to assess damage and trends." />
        </div>
      </section>

      <section id="impact" className="mx-auto max-w-6xl px-4 pb-24">
        <div className="rounded-2xl border bg-gradient-to-br from-secondary/20 via-background to-background p-6 md:p-10">
          <div className="grid gap-6 md:grid-cols-2 md:items-center">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">Real impact for people and nature</h2>
              <ul className="mt-4 grid gap-3 text-sm text-muted-foreground">
                <li className="flex items-start gap-2"><span className="mt-1 inline-block h-2 w-2 rounded-full bg-primary" /> Improves surveillance and protection of mangroves.</li>
                <li className="flex items-start gap-2"><span className="mt-1 inline-block h-2 w-2 rounded-full bg-primary" /> Empowers local communities to take active roles in conservation.</li>
                <li className="flex items-start gap-2"><span className="mt-1 inline-block h-2 w-2 rounded-full bg-primary" /> Provides reliable, real-time data to authorities for enforcement and policy.</li>
              </ul>
            </div>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Stakeholders</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-3 text-sm">
                <Stakeholder label="Coastal communities" />
                <Stakeholder label="Fishermen" />
                <Stakeholder label="NGOs" />
                <Stakeholder label="Forestry Dept." />
                <Stakeholder label="Researchers" />
                <Stakeholder label="Volunteers" />
              </CardContent>
            </Card>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            <Badge>Mobile app</Badge>
            <Badge>SMS reporting</Badge>
            <Badge>Geotagging</Badge>
            <Badge>Satellite APIs</Badge>
            <Badge>AI/ML validation</Badge>
            <Badge>Gamification</Badge>
            <Badge>Cloud dashboard</Badge>
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 text-primary">{icon}</span>
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground">{desc}</p>
      </CardContent>
    </Card>
  );
}

function LeaderboardRow({ place, name, points, highlight }: { place: number; name: string; points: number; highlight?: boolean }) {
  return (
    <div className={`flex items-center justify-between rounded-lg border px-3 py-2 text-sm ${highlight ? "bg-primary/5" : ""}`}>
      <div className="flex items-center gap-2">
        <span className="inline-flex h-6 w-6 items-center justify-center rounded-md bg-muted text-xs font-semibold">{place}</span>
        <span className="font-medium">{name}</span>
      </div>
      <div className="flex items-center gap-2 text-muted-foreground">
        <Users className="h-4 w-4" />
        <span className="tabular-nums">{points}</span>
      </div>
    </div>
  );
}

function Stakeholder({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-2 rounded-md border bg-card/70 px-3 py-2">
      <Users className="h-4 w-4 text-primary" />
      <span>{label}</span>
    </div>
  );
}
