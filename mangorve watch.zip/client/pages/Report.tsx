import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Camera, MapPin, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

const MAPTILER_KEY = (import.meta as any).env?.VITE_MAPTILER_KEY as string | undefined;

function toDecimal([num, den]: { numerator: number; denominator: number }) {
  return den ? num / den : 0;
}

async function readExifGPS(file: File): Promise<{ lat: number; lon: number } | null> {
  try {
    const buf = await file.arrayBuffer();
    const view = new DataView(buf);
    // JPEG only
    if (view.getUint16(0) !== 0xffd8) return null;
    let offset = 2;
    const length = view.byteLength;
    while (offset < length) {
      const marker = view.getUint16(offset);
      offset += 2;
      if (marker === 0xffe1) {
        const size = view.getUint16(offset);
        offset += 2;
        // Exif header
        if (
          view.getUint32(offset) === 0x45786966 &&
          view.getUint16(offset + 4) === 0x0000
        ) {
          let tiffOffset = offset + 6;
          const little = view.getUint16(tiffOffset) === 0x4949;
          const getUint16 = (o: number) => view.getUint16(o, little);
          const getUint32 = (o: number) => view.getUint32(o, little);
          const firstIFDOffset = getUint32(tiffOffset + 4);
          const ifd0 = tiffOffset + firstIFDOffset;
          const entries = getUint16(ifd0);
          let gpsIFDOffset = 0;
          for (let i = 0; i < entries; i++) {
            const entry = ifd0 + 2 + i * 12;
            const tag = getUint16(entry);
            if (tag === 0x8825) {
              gpsIFDOffset = getUint32(entry + 8);
              break;
            }
          }
          if (!gpsIFDOffset) return null;
          const gpsIFD = tiffOffset + gpsIFDOffset;
          const gpsCount = getUint16(gpsIFD);
          let latRef = "N";
          let lonRef = "E";
          let latVals: { numerator: number; denominator: number }[] | null = null;
          let lonVals: { numerator: number; denominator: number }[] | null = null;
          for (let i = 0; i < gpsCount; i++) {
            const entry = gpsIFD + 2 + i * 12;
            const tag = getUint16(entry);
            const type = getUint16(entry + 2);
            const count = getUint32(entry + 4);
            const valueOffset = getUint32(entry + 8);
            if (tag === 1) {
              // GPSLatitudeRef
              latRef = String.fromCharCode(view.getUint8(tiffOffset + valueOffset));
            } else if (tag === 2 && type === 5 && count === 3) {
              // GPSLatitude
              latVals = [0, 1, 2].map((j) => {
                const o = tiffOffset + valueOffset + j * 8;
                return { numerator: getUint32(o), denominator: getUint32(o + 4) };
              });
            } else if (tag === 3) {
              // GPSLongitudeRef
              lonRef = String.fromCharCode(view.getUint8(tiffOffset + valueOffset));
            } else if (tag === 4 && type === 5 && count === 3) {
              // GPSLongitude
              lonVals = [0, 1, 2].map((j) => {
                const o = tiffOffset + valueOffset + j * 8;
                return { numerator: getUint32(o), denominator: getUint32(o + 4) };
              });
            }
          }
          if (!latVals || !lonVals) return null;
          const lat = (toDecimal(latVals[0]) + toDecimal(latVals[1]) / 60 + toDecimal(latVals[2]) / 3600) * (latRef === "S" ? -1 : 1);
          const lon = (toDecimal(lonVals[0]) + toDecimal(lonVals[1]) / 60 + toDecimal(lonVals[2]) / 3600) * (lonRef === "W" ? -1 : 1);
          return { lat, lon };
        }
        offset += size - 2;
      } else if (marker === 0xffda) {
        break; // Start of stream
      } else {
        offset += view.getUint16(offset);
      }
    }
  } catch {
    // ignore parsing errors
  }
  return null;
}

export default function Report() {
  const [coords, setCoords] = useState<{ lat: number; lon: number } | null>(null);
  const [photo, setPhoto] = useState<string | null>(null);
  const [category, setCategory] = useState<string>("mangrove_cutting");
  const [description, setDescription] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [locLoading, setLocLoading] = useState(false);

  useEffect(() => {
    requestLocation();
  }, []);

  function requestLocation() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setCoords({ lat: pos.coords.latitude, lon: pos.coords.longitude }),
      () => {},
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 10000 },
    );
  }

  async function ipFallback() {
    try {
      setLocLoading(true);
      const res = await fetch("https://ipapi.co/json/");
      const data = await res.json();
      if (data && typeof data.latitude === "number" && typeof data.longitude === "number") {
        setCoords({ lat: data.latitude, lon: data.longitude });
      } else if (data && data.latitude && data.longitude) {
        setCoords({ lat: Number(data.latitude), lon: Number(data.longitude) });
      }
    } catch {
      toast.error("Could not detect location from network");
    } finally {
      setLocLoading(false);
    }
  }

  useEffect(() => {
    const t = setTimeout(() => {
      if (!coords) ipFallback();
    }, 2000);
    return () => clearTimeout(t);
  }, [coords]);

  const mapUrl = useMemo(() => {
    if (!coords) return null;
    const { lat, lon } = coords;
    const z = 15;
    if (MAPTILER_KEY) {
      const size = { w: 600, h: 300 };
      return `https://api.maptiler.com/maps/satellite-v2/static/${lon},${lat},${z}/${size.w}x${size.h}.jpg?key=${MAPTILER_KEY}&attribution=false`;
    }
    const x = Math.floor(((lon + 180) / 360) * Math.pow(2, z));
    const y = Math.floor(
      ((1 - Math.log(Math.tan((lat * Math.PI) / 180) + 1 / Math.cos((lat * Math.PI) / 180)) / Math.PI) / 2) * Math.pow(2, z),
    );
    return `https://tile.openstreetmap.org/${z}/${x}/${y}.png`;
  }, [coords]);

  async function onFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => setPhoto(reader.result as string);
    reader.readAsDataURL(f);

    // Auto-fetch location on upload
    requestLocation();
    // Try EXIF GPS as fallback
    const gps = await readExifGPS(f);
    if (gps) setCoords(gps);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const payload = {
        id: crypto.randomUUID(),
        ts: Date.now(),
        category,
        description,
        coords,
        photo,
      };
      const existing = JSON.parse(localStorage.getItem("mg_reports") || "[]");
      existing.unshift(payload);
      localStorage.setItem("mg_reports", JSON.stringify(existing));
      const pts = Number(localStorage.getItem("mg_points") || "0") + 50;
      localStorage.setItem("mg_points", String(pts));
      toast.success("Report submitted", { description: "You earned +50 points" });
      setDescription("");
      setPhoto(null);
    } finally {
      setSubmitting(false);
    }
  }

  function buildSmsLink(body: string, to?: string) {
    const ios = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const base = `sms:${to ?? ""}`;
    const sep = ios ? "&" : "?";
    return `${base}${sep}body=${encodeURIComponent(body)}`;
  }

  function smsBody() {
    const loc = coords ? ` @ ${coords.lat.toFixed(5)}, ${coords.lon.toFixed(5)}` : "";
    return `Mangrove incident: ${category}${loc}. ${description}`;
  }

  async function handleSms() {
    const body = smsBody();
    try {
      const anyNav = navigator as any;
      if (anyNav?.canShare?.({ text: body }) || anyNav?.share) {
        await anyNav.share({ text: body });
        return;
      }
    } catch {}
    try {
      window.location.href = buildSmsLink(body);
    } finally {
      try {
        await navigator.clipboard.writeText(body);
        toast.message("SMS text copied", { description: "If the SMS app didn't open, paste the message manually." });
      } catch {}
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 pb-24 pt-4 md:pt-8">
      <h1 className="mb-4 text-2xl font-bold tracking-tight">Report Incident</h1>
      <p className="mb-6 text-sm text-muted-foreground">
        Help protect mangroves by reporting cutting, dumping, or encroachment. Add a photo and a short description. Your location helps authorities act quickly.
      </p>

      <form onSubmit={onSubmit} className="space-y-6">
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-base">
              <Camera className="h-4 w-4 text-primary" /> Attach Photo
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {photo ? (
              <div className="relative overflow-hidden rounded-md border">
                <img src={photo} alt="Selected" className="h-56 w-full object-cover" />
              </div>
            ) : (
              <Label
                htmlFor="photo"
                className="flex h-40 cursor-pointer items-center justify-center rounded-md border border-dashed bg-muted/30 text-sm text-muted-foreground hover:bg-muted/50"
              >
                Tap to capture or upload
                <input
                  id="photo"
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="sr-only"
                  onChange={onFileChange}
                />
              </Label>
            )}
            {photo && (
              <div className="flex gap-2">
                <Button type="button" variant="secondary" onClick={() => setPhoto(null)}>
                  Remove
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-base">
              <MapPin className="h-4 w-4 text-primary" /> Location
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {coords ? (
              <div className="flex items-center gap-2 text-sm">
                <Badge variant="secondary">Lat {coords.lat.toFixed(5)}</Badge>
                <Badge variant="secondary">Lon {coords.lon.toFixed(5)}</Badge>
                {MAPTILER_KEY ? (
                  <Badge className="ml-auto" variant="outline">Satellite</Badge>
                ) : (
                  <Badge className="ml-auto" variant="outline">Map</Badge>
                )}
                <CheckCircle2 className="h-4 w-4 text-green-600" />
              </div>
            ) : (
              <div className="flex items-center justify-between gap-3 text-sm text-muted-foreground">
                <p>We couldn't access your GPS. You can still submit your report.</p>
                <Button type="button" variant="outline" size="sm" onClick={ipFallback} disabled={locLoading}>
                  {locLoading ? "Detecting..." : "Use network location"}
                </Button>
              </div>
            )}
            {mapUrl && (
              <img src={mapUrl} alt="Location preview" className="h-40 w-full rounded-md border object-cover" />
            )}
          </CardContent>
        </Card>

        <div className="grid gap-4">
          <div className="grid gap-2">
            <Label>Category</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mangrove_cutting">Mangrove cutting</SelectItem>
                <SelectItem value="dumping">Dumping / Pollution</SelectItem>
                <SelectItem value="encroachment">Encroachment / Land reclamation</SelectItem>
                <SelectItem value="illegal_fishing">Illegal fishing</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="desc">Description</Label>
            <Textarea
              id="desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Briefly describe what you observed..."
              rows={4}
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="contact">Contact (optional)</Label>
            <Input id="contact" type="tel" inputMode="tel" placeholder="Phone or email" />
          </div>
        </div>

        <div className="flex gap-3">
          <Button type="submit" className="flex-1" disabled={submitting}>
            Submit report
          </Button>
          <Button type="button" variant="outline" className="flex-1" onClick={handleSms}>
            Send via SMS
          </Button>
        </div>
      </form>
    </div>
  );
}
