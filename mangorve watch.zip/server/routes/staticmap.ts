import type { RequestHandler } from "express";

const MAPTILER_KEY = process.env.MAPTILER_KEY || process.env.VITE_MAPTILER_KEY;

export const handleStaticMap: RequestHandler = async (req, res) => {
  const lat = parseFloat(String(req.query.lat));
  const lon = parseFloat(String(req.query.lon));
  const z = parseInt(String(req.query.z || "15"));
  const w = parseInt(String(req.query.w || "600"));
  const h = parseInt(String(req.query.h || "300"));
  const sat = String(req.query.sat || "0") === "1";

  if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
    res.status(400).json({ error: "Invalid coordinates" });
    return;
  }

  let url: string;
  if (sat && MAPTILER_KEY) {
    url = `https://api.maptiler.com/maps/satellite-v2/static/${lon},${lat},${z}/${w}x${h}.jpg?key=${MAPTILER_KEY}&attribution=false`;
  } else {
    const marker = `${lat},${lon},lightblue1`;
    url = `https://staticmap.openstreetmap.de/staticmap.php?center=${lat},${lon}&zoom=${z}&size=${w}x${h}&markers=${marker}`;
  }

  try {
    const r = await fetch(url);
    if (!r.ok) {
      res.status(r.status).end();
      return;
    }
    const ct = r.headers.get("content-type") || "image/jpeg";
    res.setHeader("Content-Type", ct);
    const buf = Buffer.from(await r.arrayBuffer());
    res.send(buf);
  } catch (e) {
    res.status(500).json({ error: "Failed to fetch map" });
  }
};
